CREATE FUNCTION round(numeric)
  RETURNS numeric
IMMUTABLE
STRICT
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.round($1,0)
$$;

